# From Class03:
### Added new template and created three issues and one project . From the I have closed the one issue with the comments ,and two are opened.
# pm-notes
## key notes from the discussion today
### Agile: 
* Agile is an iterative approach to project management and software development that helps teams deliver value to their customers faster and with fewer headaches. ... Requirements, plans, and results are evaluated continuously so teams have a natural mechanism for responding to change quickly.
### SCRUM:
* Scrum is a lightweight agile process framework used primarily for managing software development. Scrum is often contrasted with the so-called “Waterfall” approach, which emphasizes up-front planning and scheduling of activities, followed by execution.
### Scrum :
* Scrum follows a set of roles, responsibilities, and meetings that never change. For example, Scrum calls for four ceremonies that provide structure to each sprint: sprint planning, daily stand-up, sprint demo, and sprint retrospective.
### Sprint:
* A sprint is a short, time-boxed period when a scrum team works to complete a set amount of work. Sprints are at the very heart of scrum and agile methodologies, and getting sprints right will help your agile team ship better software with fewer headaches.
### Four frames of organization:
1. Structural frame
2. Human resource frame
3. Political frame
4. Symbolic frame
### Project and product life cycles
* It is good practice to divide projects into several phases.
* Because projects operate as part of a system and involve uncertainty.
* The same can be said for developing products.

### Agile Process

![image](https://user-images.githubusercontent.com/77756728/118032353-30e2c400-b32d-11eb-9a3a-295e0f166b96.png)

